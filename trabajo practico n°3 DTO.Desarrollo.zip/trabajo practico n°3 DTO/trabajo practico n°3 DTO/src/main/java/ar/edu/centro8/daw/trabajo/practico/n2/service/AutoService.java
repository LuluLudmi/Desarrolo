package ar.edu.centro8.daw.trabajo.practico.n2.service;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ar.edu.centro8.daw.trabajo.practico.n2.model.Auto;
import ar.edu.centro8.daw.trabajo.practico.n2.repository.IAutoRepository;
import ar.edu.centro8.daw.trabajo.practico.n2.dto.AutoRequestDTO;
import ar.edu.centro8.daw.trabajo.practico.n2.dto.AutoResponseDTO;
import ar.edu.centro8.daw.trabajo.practico.n2.dto.AutoMapper;

@Service
public class AutoService implements IAutoService {
    @Autowired
    private IAutoRepository autoRepo;

    @Autowired
    private AutoMapper autoMapper;

    @Override
    public List<AutoResponseDTO> getAutos() {
        return autoRepo.findAll().stream()
                .map(autoMapper::toResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public AutoResponseDTO saveAuto(AutoRequestDTO autoDTO) {
        try {
            autoDTO.validar();
        } catch (Exception e) {
            throw new IllegalArgumentException(e.getMessage());
        }

        Auto auto = autoMapper.toEntity(autoDTO);
        Auto autoGuardado = autoRepo.save(auto);
        return autoMapper.toResponseDTO(autoGuardado);
    }

    @Override
    public void deleteAuto(Long id) {
        if (!autoRepo.existsById(id)) {
            throw new IllegalArgumentException("Auto no encontrado con id: " + id);
        }
        autoRepo.deleteById(id);
    }

    @Override
    public AutoResponseDTO findAuto(Long id) {
        Auto auto = autoRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Auto no encontrado con id: " + id));
        return autoMapper.toResponseDTO(auto);
    }

    @Override
    public AutoResponseDTO editAuto(Long id, AutoRequestDTO autoDTO) {
        try {
            autoDTO.validar();
        } catch (Exception e) {
            throw new IllegalArgumentException(e.getMessage());
        }

        Auto auto = autoRepo.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Auto no encontrado con id: " + id));

        autoMapper.updateEntityFromDTO(auto, autoDTO);
        Auto autoActualizado = autoRepo.save(auto);
        return autoMapper.toResponseDTO(autoActualizado);
    }
}
