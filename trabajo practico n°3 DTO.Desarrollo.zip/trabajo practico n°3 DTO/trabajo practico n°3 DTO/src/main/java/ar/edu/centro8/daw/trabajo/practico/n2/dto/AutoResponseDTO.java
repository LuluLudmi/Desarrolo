package ar.edu.centro8.daw.trabajo.practico.n2.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter

public class AutoResponseDTO {
    private Long id;
    private String marca;
    private double precio;

    public AutoResponseDTO() {
    }

    public AutoResponseDTO(Long id, String marca, int precio) {
        this.id = id;
        this.marca = marca;
        this.precio = precio;
    }

}
