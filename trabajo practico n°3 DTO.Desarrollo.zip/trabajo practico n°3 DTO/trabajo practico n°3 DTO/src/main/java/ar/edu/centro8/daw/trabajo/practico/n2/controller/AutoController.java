package ar.edu.centro8.daw.trabajo.practico.n2.controller;

import java.util.List;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import ar.edu.centro8.daw.trabajo.practico.n2.dto.AutoRequestDTO;
import ar.edu.centro8.daw.trabajo.practico.n2.dto.AutoResponseDTO;
import ar.edu.centro8.daw.trabajo.practico.n2.service.IAutoService;

@RestController
@CrossOrigin(origins = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
        RequestMethod.DELETE })

public class AutoController {
    @Autowired
    private IAutoService autoServ;

    /**
     * Obtener todos los autos
     */
    @GetMapping("/autos/traer")
    public ResponseEntity<List<AutoResponseDTO>> getAutos() {
        try {
            List<AutoResponseDTO> autos = autoServ.getAutos();
            return ResponseEntity.ok(autos);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Crear un nuevo auto
     */
    @PostMapping("/autos/crear")
    public ResponseEntity<?> saveAuto(@RequestBody AutoRequestDTO autoDTO) {
        try {
            AutoResponseDTO autoCreado = autoServ.saveAuto(autoDTO);
            return ResponseEntity.status(HttpStatus.CREATED).body(autoCreado);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error interno del servidor");
        }
    }

    /**
     * Obtener un auto por ID
     */
    @GetMapping("/autos/{id}")
    public ResponseEntity<?> getAuto(@PathVariable Long id) {
        try {
            AutoResponseDTO auto = autoServ.findAuto(id);
            return ResponseEntity.ok(auto);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.notFound().build();
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    /**
     * Eliminar un auto
     */
    @DeleteMapping("/autos/borrar/{id}")
    public ResponseEntity<String> deleteAuto(@PathVariable Long id) {
        try {
            autoServ.deleteAuto(id);
            return ResponseEntity.ok("El auto fue eliminado correctamente");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error al eliminar el auto");
        }
    }

    /**
     * Editar un auto
     */
    @PutMapping("/autos/editar/{id}")
    public ResponseEntity<?> editAuto(@PathVariable Long id,
            @RequestBody AutoRequestDTO autoDTO) {
        try {
            AutoResponseDTO autoActualizado = autoServ.editAuto(id, autoDTO);
            return ResponseEntity.ok(autoActualizado);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body("Error: " + e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error interno del servidor");
        }
    }

}