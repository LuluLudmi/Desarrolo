package ar.edu.centro8.daw.trabajo.practico.n2.service;

import java.util.List;
import ar.edu.centro8.daw.trabajo.practico.n2.dto.AutoRequestDTO;
import ar.edu.centro8.daw.trabajo.practico.n2.dto.AutoResponseDTO;

public interface IAutoService {
  public List<AutoResponseDTO> getAutos();

  public AutoResponseDTO saveAuto(AutoRequestDTO autoDTO);

  public void deleteAuto(Long id);

  public AutoResponseDTO findAuto(Long id);

  public AutoResponseDTO editAuto(Long id, AutoRequestDTO autoDTO);
}
