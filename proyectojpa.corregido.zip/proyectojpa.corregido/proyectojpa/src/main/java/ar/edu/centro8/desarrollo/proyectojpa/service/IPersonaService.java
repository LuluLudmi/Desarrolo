package ar.edu.centro8.desarrollo.proyectojpa.service;

import java.util.List;
import ar.edu.centro8.desarrollo.proyectojpa.model.Persona;

public interface IPersonaService {
    // lectura
    List<Persona> getPersonas();

    // alta
    void savePersona(Persona perso);

    // baja
    void deletePersona(Long id);

    // lectura de un solo objeto
    Persona findPersona(Long id);

    // edición/modificación
    void editPersona(Long idOriginal, Long idNueva, String nuevoNombre, Integer nuevaEdad); // 👈 corregido
}