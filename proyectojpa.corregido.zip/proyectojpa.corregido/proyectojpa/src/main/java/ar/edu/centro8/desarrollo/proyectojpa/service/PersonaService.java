package ar.edu.centro8.desarrollo.proyectojpa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ar.edu.centro8.desarrollo.proyectojpa.model.Persona;
import ar.edu.centro8.desarrollo.proyectojpa.repository.IPersonaRepository;

@Service
public class PersonaService implements IPersonaService {

    @Autowired
    private IPersonaRepository persoRepo;

    @Override
    public List<Persona> getPersonas() {
        return persoRepo.findAll();
    }

    @Override
    public void savePersona(Persona perso) {
        persoRepo.save(perso);
    }

    @Override
    public void deletePersona(Long id) {
        persoRepo.deleteById(id);
    }

    @Override
    public Persona findPersona(Long id) {
        return persoRepo.findById(id).orElse(null);
    }

    @Override
    public void editPersona(Long idOriginal, Long idNueva, String nuevoNombre, Integer nuevaEdad) {
        Persona persona = persoRepo.findById(idOriginal)
                .orElseThrow(() -> new RuntimeException("Persona no encontrada"));

        if (idNueva != null)
            persona.setId(idNueva);
        if (nuevoNombre != null)
            persona.setNombre(nuevoNombre);
        if (nuevaEdad != null)
            persona.setEdad(nuevaEdad);

        System.out.println("Editando persona: " + idOriginal);
        System.out.println("Nuevo ID: " + idNueva);
        System.out.println("Nuevo nombre: " + nuevoNombre);
        System.out.println("Nueva edad: " + nuevaEdad);

        persoRepo.save(persona);
    }
}