package ar.edu.centro8.daw.dinamico.controller;

// import java.util.ArrayList;
// import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
// import org.springframework.web.bind.annotation.ResponseBody;

import ar.edu.centro8.daw.dinamico.model.Cliente;


@RestController

public class ClienteController {
    @GetMapping("/")
    public String saludar() {
        return "Hola Mundo!";
    }
    @GetMapping("/{nombre}")
    public String saludar2(@PathVariable String nombre){
        return "Hola " + nombre + ", Como estas loco!";
    }
    @GetMapping("/{nombre}/{edad}")
    public String saludar3(@PathVariable String nombre, @PathVariable int edad){
        return "Hola " + nombre + ", Como estas loco! Veo que estas mas viejo " + edad + " años.";
    }
    @GetMapping("/cliente")
    public String saludar4(@PathVariable String nombre, @PathVariable int edad){
        return "Hola " + nombre + ", Como estas? Asi que tenes " + edad + " años.";
    }

    @PostMapping("/cliente")
    public String saludar5(@RequestBody Cliente c){
        return "Hola " + c.getNombre() + " , como estas! Asi que tenes " + c.getEdad() + "años." ;
    
    }

    // @GetMapping("/cliente/traer")
    // @ResponseBody
    // public List<Cliente> traerCliente(){
    //     List<Cliente> clientes = new ArrayList<>();

    //     clientes.add(new Cliente(nombre:"Juan", edad:25));

    
    



}
