package ar.edu.centro8.daw.dinamico.model;

import lombok.Data;

@Data
public class Cliente {
    private String nombre;
    private int edad;

}
