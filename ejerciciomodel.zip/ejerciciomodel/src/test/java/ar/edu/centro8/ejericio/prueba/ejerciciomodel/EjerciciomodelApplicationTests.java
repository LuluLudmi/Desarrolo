package ar.edu.centro8.ejericio.prueba.ejerciciomodel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjerciciomodelApplicationTests {

	@Test
	void contextLoads() {
	}

}
