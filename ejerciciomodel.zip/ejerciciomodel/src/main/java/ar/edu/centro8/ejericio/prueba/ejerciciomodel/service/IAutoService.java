package ar.edu.centro8.ejericio.prueba.ejerciciomodel.service;

import java.util.List;

import org.springframework.stereotype.Repository;

import ar.edu.centro8.ejericio.prueba.ejerciciomodel.model.Auto;

@Repository
public interface IAutoService{

    public List<Auto> getAutos();

    public void save(Auto auto);

    public void delete(int id);

    public Auto findById(int id);

    public void editAuto(int id, String marca, String modelo, int anio, String color);
}
