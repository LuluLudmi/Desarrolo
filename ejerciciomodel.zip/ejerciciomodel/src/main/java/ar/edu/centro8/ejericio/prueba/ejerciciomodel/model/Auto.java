package ar.edu.centro8.ejericio.prueba.ejerciciomodel.model;

import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Entity
@AllArgsConstructor
@Getter
@Setter

public class Auto {
    @Id
    private int id;
    private String marca;
    private String modelo;
    private int anio;
    private String color;

    public Auto() {
    }

}
