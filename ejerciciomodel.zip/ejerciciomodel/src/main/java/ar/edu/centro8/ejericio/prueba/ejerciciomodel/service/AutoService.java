package ar.edu.centro8.ejericio.prueba.ejerciciomodel.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import ar.edu.centro8.ejericio.prueba.ejerciciomodel.repository.IAutoRepository;

@Service

public class AutoService implements IAutoService {

    @Autowired
    private IAutoRepository autoRepository;

    @Override
    public List<Auto> getAutos() {
        List<Auto> listaAutos = autoRepository.findAll();
        return listaAutos;
    }


    @Override
    public void save(Auto auto) {
        autoRepository.save(auto);
    }

    @Override
    public void delete(int id) {
        autoRepository.deleteById(id);
    }

    @Override
    public Auto findById(int id) {
        return autoRepository.findById(id).orElse(null);
    }

    @Override
    public void editAuto(int id, String marca, String modelo, int anio, String color) {
        Auto auto = findById(id);
        if (auto != null) {
            auto.setMarca(marca);
            auto.setModelo(modelo);
            auto.setAnio(anio);
            auto.setColor(color);
            save(auto);
        }
    }
}
