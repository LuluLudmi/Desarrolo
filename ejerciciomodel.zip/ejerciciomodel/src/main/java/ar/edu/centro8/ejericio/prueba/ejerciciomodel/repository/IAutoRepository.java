package ar.edu.centro8.ejericio.prueba.ejerciciomodel.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ar.edu.centro8.ejericio.prueba.ejerciciomodel.model.Auto;

public interface IAutoRepository extends JpaRepository<Auto, Integer> {
    
}
