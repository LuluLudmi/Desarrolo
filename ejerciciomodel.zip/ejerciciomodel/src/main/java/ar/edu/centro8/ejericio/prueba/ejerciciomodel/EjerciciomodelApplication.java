package ar.edu.centro8.ejericio.prueba.ejerciciomodel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjerciciomodelApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjerciciomodelApplication.class, args);
	}

}
