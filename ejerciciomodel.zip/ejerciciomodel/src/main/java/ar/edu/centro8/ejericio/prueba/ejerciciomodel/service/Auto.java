package ar.edu.centro8.ejericio.prueba.ejerciciomodel.service;

public class Auto {

}
