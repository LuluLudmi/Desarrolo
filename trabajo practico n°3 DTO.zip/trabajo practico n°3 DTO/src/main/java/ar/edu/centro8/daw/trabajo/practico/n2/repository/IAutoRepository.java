package ar.edu.centro8.daw.trabajo.practico.n2.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import ar.edu.centro8.daw.trabajo.practico.n2.model.Auto;

@Repository
public interface IAutoRepository extends JpaRepository<Auto, Long> {
    Optional<Auto> findByMarca(String marca);
    List<Auto> findByPrecio(int precio);
    List<Auto> fndByPrecioGreaterThan(int precio);
    Optional<Auto> findByMarcaIgnoreCase(String marca);
    List<Auto> findByPrecioBetween(int desde, int hasta);
    Long countByMarca(String marca);
}
