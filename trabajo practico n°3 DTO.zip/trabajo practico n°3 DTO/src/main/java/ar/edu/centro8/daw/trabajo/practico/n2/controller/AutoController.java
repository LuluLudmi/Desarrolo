package ar.edu.centro8.daw.trabajo.practico.n2.controller;

import java.util.List;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import ar.edu.centro8.daw.trabajo.practico.n2.dto.AutoResponseDTO;
import ar.edu.centro8.daw.trabajo.practico.n2.model.Auto;
import ar.edu.centro8.daw.trabajo.practico.n2.service.IAutoService;

@RestController
@CrossOrigin(origins = "*", methods = { RequestMethod.GET, RequestMethod.POST, RequestMethod.PUT,
        RequestMethod.DELETE })

public class AutoController {
    @Autowired
    private IAutoService autoServ;

    @GetMapping("/autos/traer")
    public ResponseEntity <List<AutoResponseDTO>> getAutos() {
    try{List<AutoResponseDTO> autos = autoServ.getAutos();
        return ResponseEntity.ok(autos);
    
    }catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
}