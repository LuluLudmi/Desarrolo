package ar.edu.centro8.daw.trabajo.practico.n2.dto;

import ar.edu.centro8.daw.trabajo.practico.n2.model.Auto;

public class AutoMapper {
    public Auto toEntity(AutoRequestDTO dto) {

        Auto auto = new Auto();
        auto.setMarca(dto.getMarca());
        auto.setPrecio(dto.getPrecio());
        return auto;
    }

    public AutoResponseDTO toResponseDTO(Auto auto) {

        return new AutoResponseDTO(
                auto.getId(),
                auto.getMarca(),
                auto.getPrecio());
    }

    public void updateEntityFromDTO(Auto auto, AutoRequestDTO dto) {

        auto.setMarca(dto.getMarca());
        auto.setPrecio(dto.getPrecio());
    }

}
