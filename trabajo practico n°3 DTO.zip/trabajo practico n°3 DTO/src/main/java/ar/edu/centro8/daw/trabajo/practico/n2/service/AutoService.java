package ar.edu.centro8.daw.trabajo.practico.n2.service;

import java.util.List;
import java.util.Optional;  
import java.util.stream.Collectors; 


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ar.edu.centro8.daw.trabajo.practico.n2.model.Auto;
import ar.edu.centro8.daw.trabajo.practico.n2.repository.IAutoRepository;
import ar .edu.centro8.daw.trabajo.practico.n2.dto.AutoMapper;
import ar.edu.centro8.daw.trabajo.practico.n2.dto.AutoRequestDTO;
import ar.edu.centro8.daw.trabajo.practico.n2.dto.AutoResponseDTO;    


@Service

public class AutoService implements IAutoService {
    @Autowired
    private IAutoRepository AutoRepo;

    @Override
    public List<AutoResponseDTO> getAutos() {
        List<Auto> listaAutos = AutoRepo.findAll();
        return listaAutos.stream()
                .map(AutoMapper::toResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    public AutoResponseDTO saveAuto(AutoRequestDTO autoDTO) {
        // Validar DTO
        autoDTO.validar();

        Auto auto = AutoMapper.toEntity(autoDTO);
        Auto savedAuto = AutoRepo.save(auto);
        return AutoMapper.toResponseDTO(savedAuto);
    }

    @Override
    public void deleteAuto(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteAuto'");
    }

    @Override
    public AutoResponseDTO findAuto(Long id) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'findAuto'");
    }

    @Override
    public AutoResponseDTO editAuto(Long id, AutoRequestDTO autoDTO) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'editAuto'");
    }
}