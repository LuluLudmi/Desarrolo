package ar.edu.centro8.daw.trabajo.practico.n2.service;

import java.util.List;

import ar.edu.centro8.daw.trabajo.practico.n2.dto.AutoRequestDTO;
import ar.edu.centro8.daw.trabajo.practico.n2.dto.AutoResponseDTO;

public interface IAutoService {

  public List<AutoResponseDTO> getAutos();

  // alta
  public AutoResponseDTO saveAuto(AutoRequestDTO autoDTO);

  // baja
  public void deleteAuto(Long id);

  // lectura de un solo objeto
  public AutoResponseDTO findAuto(Long id);

  // edición/modificación
  public AutoResponseDTO editAuto(Long id, AutoRequestDTO autoDTO);

}
