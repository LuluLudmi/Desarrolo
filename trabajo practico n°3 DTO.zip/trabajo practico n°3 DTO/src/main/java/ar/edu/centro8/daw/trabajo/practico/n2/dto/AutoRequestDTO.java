package ar.edu.centro8.daw.trabajo.practico.n2.dto;
import lombok.Getter;
import lombok.Setter;

@Getter 
@Setter 
public class AutoRequestDTO {
    private String marca;
    private int precio;

    public AutoRequestDTO() {
    }

    public AutoRequestDTO(String marca, int precio) {
        this.marca = marca;
        this.precio = precio;
    }

    public void validarMarca() throws Exception {
        if (marca == null || marca.trim().isEmpty()) {
            throw new Exception("La marca no puede estar vacía");
        }
        if (marca.length() < 2 || marca.length() > 50) {
            throw new Exception("La marca debe tener entre 2 y 15 caracteres");
        }
        this.marca = marca.trim();
    }

    public void validar() throws Exception {
        validarMarca();
    }

}
