-- Crear la base de datos
CREATE DATABASE proyecto_auto;
DROP DATABASE editoriales;