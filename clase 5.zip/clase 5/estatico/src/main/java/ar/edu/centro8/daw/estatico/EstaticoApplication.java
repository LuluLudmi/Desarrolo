package ar.edu.centro8.daw.estatico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstaticoApplication {

	public static void main(String[] args) {
		SpringApplication.run(EstaticoApplication.class, args);
	}

}
