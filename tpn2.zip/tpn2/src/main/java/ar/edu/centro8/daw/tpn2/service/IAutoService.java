package ar.edu.centro8.daw.tpn2.service;

import java.util.List;

import ar.edu.centro8.daw.tpn2.model.Auto;

public interface IAutoService {
    public List <Auto> getAutos();

    public void save (Auto auto);

    public void delete (Long id);

    public Auto findById (Long id);

    public void editAuto(Long idOriginal, Long idNueva, String nuevaMarca, int nuevoPrecio);

}

