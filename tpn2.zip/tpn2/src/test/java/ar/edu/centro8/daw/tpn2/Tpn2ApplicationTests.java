package ar.edu.centro8.daw.tpn2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tpn2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
